﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minipokemon
{
    public class Gugu : Monster
    {

        public Gugu()
        {


            monsterName = "구구";
            monsterHP = 30;
            monsterMAXHP = 30;
            monsterBaseATK = 5;
            monsterSkillName = "바람 일으키기";

            
        }


    }
}

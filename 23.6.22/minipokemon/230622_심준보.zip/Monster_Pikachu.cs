﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minipokemon
{
    public class Pikachu : Monster
    {


        public Pikachu()
        {

            monsterName = "피카츄";
            monsterHP = 50;
            monsterMAXHP = 50;
            monsterBaseATK = 10;
            monsterSkillName = "10만 볼트";


        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minipokemon
{
    public class Korett : Monster
    {

        public Korett()
        {

            monsterName = "꼬렛";
            monsterHP = 35;
            monsterMAXHP = 35;
            monsterBaseATK = 8;
            monsterSkillName = "필살 엄니";


        }


    }

}


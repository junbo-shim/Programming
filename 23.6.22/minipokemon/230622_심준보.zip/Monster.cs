﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace minipokemon
//{
//    public class Monster
//    {

//        public string monsterName { get; private set; }

//        public int monsterHP { get; private set; }

//        public int monsterMAXHP { get; private set; }

//        public int monsterBaseATK { get; private set; }
//        public (string monsterName, int monsterHP, int monsterMAXHP, int monsterBaseATK) {
        
        
        
//        }

//    public virtual void init(string monstername, int monsterHP, int monsterMAXHP, int monsterBaseATK)
//    {
//        this.monsterName = monstername;
//        this.monsterHP = monsterHP;
//        this.monsterMAXHP = monsterMAXHP;
//        this.monsterBaseATK = monsterBaseATK;
//    }





//    public virtual void Skill()
//    {


//    }



//}


//public class Slime : Monster
//{
//    public string monsterName = " ";
//    public void init()
//    {
//        base.init("슬랑임", 50, 50, 15);
//    }

//    int flexible;
//    public void init(string monstername, int monsterHP, int monsterMAXHP, int monsterBaseATK, int flexiable)
//    {
//        base.init(monstername, monsterHP, monsterMAXHP, monsterBaseATK);

//        this.flexible = flexiable;

//    }
//}
        

//}








﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace minipokemon
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Map map001 = new Map();
            map001.DoMap();


            List<Monster> monsters = new List<Monster>();
            monsters.Add(new Monster());

        }
    }
}

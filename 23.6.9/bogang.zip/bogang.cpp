﻿#include<stdio.h>

//정수데이터(.이 없는 숫자) -> int
//실수데이터(.이 들어간 숫자) -> double
//문자 데이터(외따옴표가 있는 문자 하나) -> int
//문자열 데이터(쌍따옴표가 있는 문자(들))
//
//자료형 변수명 = 넣을 데이터; (int number = 5;)
//
//정수 자료형 - 용량이 커짐 (char, short, int, long, long long)
//char (1byte) : 가장 작은 용량의 정수 자료형 / 주로 문자 데이터를 담을 떄 쓰임
//int (4byte) : 정수 데이터를 사용할 때 쓰는 자료형
//short (2byte) : 변수보다 용량을 아낄 때 쓰는 자료형
//long (4byte) : 과거에 16비트 시절일때 int가 2byte 였음
//long long (8byte) : long의 문제점을 해결하기 위해서 나중에 나온 자료형
//
//
//실수 자료형 - 소수점 표현이 세밀해짐 (float, double, long double)
//float (4byte) : double 보다 빠르게 실수 데이터를 연산하기 위해 쓰이는 자료형
//double (8byte) : 기본적으로 실수 데이터 사용할 때 쓰이는 자료형
//long double (16byte) : double보다 더 정밀한 실수를 표현하기 위해 쓰이는 자료형 / 비주얼 스튜디오에서는 8 byte임
// %.20f



//unsigned int->무조건 양수로 고정
//unsigned char 와 signed char->숫자데이터일 경우
//char -> 'A' 문자데이터일 경우는 안붙여도 된다
//
//int num; // -21억~21억
//signed num; // -21억~21억
//unsigned num; // 0~42억
//
//signed char num; // -128 ~ 127
//unsigned char num // 0~255
//
//float, double -> signed unsigned 둘 다 없음
//
//컴퓨터는 실수 데이터를 표현할때 부호 있는 방식으로만 표현하기 때문에 항상 signed 데이터만 존재함 / 그러므로 unsigned는 없음




//리터럴 접미사
//= 변수에 데이터를 넣기 위해서는 넣을 데이터의 타입과 똑같은 자료형을 명시해줘야 한다
//int나 double 이외의 데이터를 표현하기 위한 문법
//
//
//정수 접미사
//long->숫자 뒤에 l을 붙이면 된다 ex. 5l
//long long->숫자 뒤에 l을 2번 붙이면 된다 ex. 5ll
//unsigned->숫자 뒤에 u를 넣으면 된다 ex. 5u
//
//실수 접미사
//float->숫자 뒤에 f를 붙임 ex. 3.14f -> 실수의 기본이 double이기 때문에 float 자료형을 붙이면 오류
//long double->숫자 뒤에 l을 붙임 ex. 3.14l
//
//
//
//접두사
//= c언어는 정수 데이터를 다른 진수로도 표현할 수 있는 문법을 지원하고 있음
//
//int number = 10; -> 10진수 10
//int number = 010; -> 8진수 010
//int number = 0x10; -> 16진수 10



아스키 코드
->컴퓨터는 모든 데이터를 숫자로 처리하기 때문에 문자라는 타입이 따로 존재하지 않는다. (인코딩)
->알파벳, 특수문자, 숫자 = 128개의 문자에 매칭 시킴

int A = 'A';
int A = 65;
-> 두개는 같음

int zero = '0';
int zero = 48;
->두개는 같음

char의 범위가 - 128~127 이기에 문자는 용량 낭비를 막기 위해 보통 char에 담는다
char A = '0'; 안전함
char A = 48; 숫자로 직접 넣는 것은 위험




연산자
=, +, -, *, / , %
sizeof();->괄호 안에 들어가는 것의 자료 크기를 알려줌 byte...

연산자 우선순위

연산자마다 결합방향도 존재
+ , -등은 좌측에서 우측으로
= 는 우측에서 좌측으로



5 / 10; ->결과 0, 자료형 int
int와 int 결과이므로 int

3 + 0.14f;->결과 3.14f, 자료형 float
int와 float 에서 컴퓨터는 더 데이터가 적게 손실되는 쪽으로 형변환시킴 -> 3 vs 3.14f

3.0f + 0.14->결과 3.14, 자료형 double
float + double 이므로 double로 출력 됨




명시적 형변환
= 데이터가 손실될 가능성이 있음

printf("%d", 2.4);
-> 2.4를 2로 받고 싶음
-> double을 int로 받음
-> 8바이트의 데이터를 4바이트로 읽다가 깨짐





암묵적 형변환

short number = 10;
->short vs int
->short number = (short)10;


int number2 = 3.14;
->int vs double
->int number2 = (int)3.14;


double num = 5 / 10;
double num = 0; (int)
double num = (double)0;




오버플로우
= > 최대값을 넘어서 최소값으로 되돌아가는 경우
= > 자료형의 최대값을 넘어갔기 때문
signed char num = 128; -> - 128
signed char num = 127 + 1; -> - 128

언더플로우
= > 최소값보다 더 작아질 경우 최대값으로 넘어가는 경우
unsigned char num = -1; -> 255
unsigned char num = 0u - 1u; -> 255

매직넘버
= > 무슨 의미인지는 모르겠지만 프로그램은 마법처럼 잘 돌아가게 만드는 데이터
= > 최대한 줄여야함

변수 만드는
= > 변수명을 통해 개발자가 데이터의 의미를 쉽게 알 수 있게 해야함
= > 또한 유지보수도 용이함

상수의 종류
1. 리터럴 상수
->말 그대로 상수

2. 심볼릭 상수
-> int square_width = 10; 변수를 상수로 선언하고 싶을때
-> const int square_width = 10;
-> 특정 변수만 읽기 전용으로 만들려는 의도




int main ()
{
	printf("%.20f", 0.1);



	return 0;
}
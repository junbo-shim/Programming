﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _6_15_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Field Field = new Field();

            Field.Make_Field();

            Field.Move_In_Field();  
          

            


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Portal
{
    internal class Program
    {
        static void Main(string[] args)
        {
            MapStart Mapstart001 = new MapStart();

            Mapstart001.DoMap();






        }
    }
}
